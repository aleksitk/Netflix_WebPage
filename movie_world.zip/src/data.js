const data = [
    {                           
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABSKjgYrlqwKZg48_7mglvDWCKQyoJZubhOpJ7ramngyv0Csjbd-HHLxf1LGR-9cUtQx9tUDOLdr3mhMUXA0yufP3xJJtiLYte9WzRX_IbDsjp1q7TQEygeg0F4HbePycYuEm.jpg?r=868',
    title: 'Under Paris',
    category: 'Next watch'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABSqsSwWjM_EoKKIbIFJqd5P6Hj-_ZeUoSMzPkFRwjkRDwHh9vUOGu_nhHTCEy3v_Kqn4BMndGd5IcAMh6LIoNBdju3sBZ31vnmo.jpg?r=0a0',
    title: 'Maharaja',
    category: 'Next watch'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABZxXAXIFTvSrn0yyehAbbtCFiX9Bor9H3_JwW7MSvQxNlAPK8LQvuFr4BFiTvLydbjFjbDw1P4PgnPRrHQDKVe3w3Ny514kRg8wH8G1c5Czd0hnJYyqHWlFnwwe4KsA9uccVrLiNP2sfLHyWCy_U-PHvmqPNEcBGnx_3cpmJyfng8Cbtv4vBiwzh5u4hCD1DqJZ_gRFlxxn8034Eest2SMTYa1X2jhcTc5jH3o6nynr7EgiDzoaJ86ftTskNvGzTcXp1xnzXwq_ha0s5jdQrOQUJeL7nsw_SdD3iIoYxOZryojE_l6k4F720.jpg?r=c77',
    title: 'Vanished into the Night',
    category: 'Next watch'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABcRV2bh_C5VwuC_ypbikeKWDxtTiVxlMrPJYPSmWlEDjuBCatI1aUH6odeLJzVCe2mLn1Pg9eHGJBgXLuGezYdxybI7S_La5sjY4kV3oKs2e2rnRDVqXUaf3SwgezkFeJT69.jpg?r=5ab',
    title: 'Blame the Game',
    category: 'Next watch'
    },                               // 4 
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABWFGElup6zqf7eg_g9gN42cXgUOWuGsRjtPPjygIuH_XHcKmJrhSyBXlxquXMDOYHvtChpSx-eVHCPSwPU7UIhYDmtlTUYtYAcYl6-0WRIvlUYnLCO07f-8dJsEFVaFgMvsGOx9Pt3yTvKutcjReLxiDn9vKdii6pNUJNuGAwGEte8KxYaZUo1AfcoDIYzsM3l-NehMGPjwCpevqgVz94SP3GAiF09MdX0e3L5pMXTyQtRTWx27IgBavjboyTeH1xLQB54TqNiQORCXhPww2Zdc7zfvrk-y3DFy-1UN59v0aolnS8hj5iyoH.jpg?r=492',
    title: 'Beverly Hills Cop: Axel F',
    category: 'Next watch'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABQNcmvqUa298uWoIvfqlHQQ2pXCGJtM8MBPOWX2yVC394ityzKyt1cfWE-TZmUa6mhX5BYJ_2d5_MQijbUyIMcnsk0OxjrCYHgexbDwN_jwuDyhWWYwx6aVHUplBAYfBJ3PU.jpg?r=ed2',
    title: 'Lift',
    category: 'Action movies'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABQUAB7P085DHqN30qQxWCFOEVcJoeWbIByNwvYFVTl14oBd-G4SwpQB1MQH5BG23x9LJaBUGv3IdIaJQb0QN-wkFQminLabsKe87C7ZF-ZjenrWSHD3saAqpk8PRaqDGAKiJ.jpg?r=4f8',
    title: 'Nowhere',
    category: 'Next watch'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABfuA-MMgcT_rF8s1n_5qs3niXyKzoP_-8ULj6Thzab7zNcM9_AnKAgjFdoDoqbbIVrMOS7o0oDr54zJlfyDq2M6k7AQrm_BMNBhoQseoD06UijEoj_VaDFB-Lxo8yopW7sG0.jpg?r=36f',
    title: 'Luther: The Fallen Sun',
    category: 'Next watch'
    },                        // 8
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABRhybUqTpg08T8TnfSlW1TPvVx4rMoeyARJusNHmFijC4KWeaoSl9QSkEFSlLFXCZC4pITSugdJhfWa1jkM8Ina1EMepcEIntBvhg4f1kvs3f51AEJbfEFSx6B718Jng8r3j.jpg?r=e0f',
    title: 'Demsel',
    category: 'Action movies'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABUxf8Oi6b-AfMTchGw1zexfCRExKjd14PmkhCXIovRIpH70VwEz4VkhB58vU0BcoJhZhzfYtNhlYVIsB50UyowN9BDl_0XCIOTsaoXLS3ORN1g8mR0cqo99LDjNB_WZQX8zI.jpg?r=a98',
    title: 'Extraction 2',
    category: 'Next watch'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABcgvveCW59u3c5CmqIOEdzKhuPsT4-JIvE_6ERm8GgDFzFTh890NE54dD93ejwnhf1M4EU1c0eNf_VKmUuSP_ReBk7kDiVpp3Q0.jpg?r=38d',
    title: 'Robin Hood',
    category: 'Action movies'
    },
    {
    image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABZ_rblqcHBS4lWmBXoMr-JRL6-oiSRFQ6E7MK-fjDNzHYvnqMFBZ3HRAmWVbMGxQtZtegrI-3qLlGyBKggmn-ES-lwULU9Qao1M.jpg?r=67e',
    title: 'Top Gun: Maverick',
    category: 'Action movies'
    },                           //12   
    {
        image: 'https://occ-0-7681-3466.1.nflxso.net/dnm/api/v6/Qs00mKCpRvrkl3HZAN5KwEL1kpE/AAAABUyOD651Q6tsQM5swZRtACoJskISIWBsAAldpU4ZoFMZEVJjEWIvB5xJfeJDUPMnq0o48wFCiIzDkPYNOEC78e9cJxoQpsawues.jpg?r=49b',
        title: 'Four Brothers',
        category: 'Action movies'
    } 
]

export default data