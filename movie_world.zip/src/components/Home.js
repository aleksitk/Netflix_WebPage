import styles from './Home.module.css';
import { React, lazy, useRef } from 'react';
import data from '../data';
const MovieCard = lazy(() => import('./MovieCard'));

function Home() {
  const nw = data.filter(x => x.category === 'Next watch');
  const am = data.filter(x => x.category === 'Action movies');
  const myElementRef = useRef(null);
  const myElementRef2 = useRef(null);

  function changePosition(x, ref) {
    if (ref.current) {
      ref.current.scrollBy({ left: x * 1000, behavior: 'smooth' });
    }
  }

  return (
    <>
      <div className={styles.present}>
        <h1 style={{ fontSize: '50px', marginBottom: '10px', fontWeight: 800 }}>Movies</h1>
        <span style={{ fontSize: '19px' }}>Movies move us like nothing else can, whether they’re scary, funny, dramatic, romantic or anywhere in-between. So many titles, so much to experience.</span>
      </div>
      <h2 style={{ fontSize: '20px', fontWeight: 400, padding: '0 3%' }}>Your Next Watch</h2>
      <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
        <div>
          <button className={styles.left} onClick={() => changePosition(-1, myElementRef)}>
            <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
              <path fill="currentColor" d="M11.56 5.56L10.5 4.5 6 9l4.5 4.5 1.06-1.06L8.12 9z"></path>
            </svg>
          </button>
        </div>
        <div className={styles.cards} ref={myElementRef}>
          {nw.map(x => (
            <MovieCard
              key={x.title}
              title={x.title}
              image={x.image}
            />
          ))}
        </div>
        <div>
          <button className={styles.right} onClick={() => changePosition(1, myElementRef)}>
            <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" className={styles.mirror}>
              <path fill="currentColor" d="M11.56 5.56L10.5 4.5 6 9l4.5 4.5 1.06-1.06L8.12 9z"></path>
            </svg>
          </button>
        </div>
      </div>

      <h2 style={{ fontSize: '20px', fontWeight: 400, padding: '0 3%' }}>Action Movies</h2>
      <div style={{ display: 'flex', flexDirection: 'row', alignItems: 'center' }}>
        <div>
          <button className={styles.left} onClick={() => changePosition(-1, myElementRef2)}>
            <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg">
              <path fill="currentColor" d="M11.56 5.56L10.5 4.5 6 9l4.5 4.5 1.06-1.06L8.12 9z"></path>
            </svg>
          </button>
        </div>
        <div className={styles.cards} ref={myElementRef2}>
          {am.map(x => (
            <MovieCard
              key={x.title}
              title={x.title}
              image={x.image}
            />
          ))}
        </div>
        <div>
          <button className={styles.right} onClick={() => changePosition(1, myElementRef2)}>
            <svg viewBox="0 0 18 18" xmlns="http://www.w3.org/2000/svg" className={styles.mirror}>
              <path fill="currentColor" d="M11.56 5.56L10.5 4.5 6 9l4.5 4.5 1.06-1.06L8.12 9z"></path>
            </svg>
          </button>
        </div>
      </div>
    </>
  );
}

export default Home;
