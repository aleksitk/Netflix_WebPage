import React from "react";
import styles from './MovieCard.module.css'

function MovieCard(prop){
    return (
    <div className={styles.card}>
        <img src={prop.image} alt="" />
        <span style={{ margin: '7px auto 0px' }}>{prop.title}</span>
        </div>
    )
}

export default MovieCard